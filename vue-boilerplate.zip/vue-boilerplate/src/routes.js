// import DeviceDetail from "./component/DeviceDetail.vue";
// import AddNewDevice from "./component/AddNewDevice.vue";
// export const routes = [
//     {path: '/devdesc', component: DeviceDetail},
//     {path: '/addnew', component: AddNewDevice},
// ];


export default [
    {
       name:'DeviceDetail',
       path:'/devdesc' ,
       component: () => import("./component/DeviceDetail.vue"),
    },
 
    {
       name:'AddNewDevice',
       path:'/addnew',
       component: () => import("./component/AddNewDevice.vue"),
    },
 
 
//     {
//        name:'usernew',
//        path:'/user/:newUser/:mode',
//        component: () => import("./components/list.vue"),
//     },
 
//     {
//        name:'new',
//        path:'/user/new',
//        component: () => import("./components/newform.vue"),
//     },
//     {
//        name:'edit',
//        path:'/user/:id/:user',
//        component: () => import('./components/edit.vue'),
//     }
 
 ];
 