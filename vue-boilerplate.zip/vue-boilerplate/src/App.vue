<template>
  <section>
    <h2>Mobile Phones List</h2>
    <!-- <addnew-device @add-newphone="AddDevice"></addnew-device> -->
    
    <AddNewDevice v-if="!showinfo"
      :list-visible="listvisible"
      @add-newphone="AddDevice"
    ></AddNewDevice>
    <ul v-if="!showinfo">
      <li v-for="device in list" v-bind:key="device.id" @click="showdetail(device.id)">
        {{ device.name }} - {{ device.price }}
        
        <button @click.stop="deleteitem(device.id)">Delete Device</button>
      </li>
    </ul>
    <device-detail v-if="showinfo"  :id="devid" :devname="devname" :devprice="devprice" :showinfo="showinfo" @close="offlist"> </device-detail>
    
  </section>
</template>

<script>
import AddNewDevice from "./component/AddNewDevice.vue";
import DeviceDetail from "./component/DeviceDetail.vue";
export default {
  data() {
    return {
      // list: ["Samsung", "Redmi", "Nokia"],
      listvisible: false,
      showinfo : false,
      devid : '',
      devname : '',
      devprice : '',
      list: [
        {
          id: "Samsung",
          name: "Samsung",
          price: "20k",
        },
        {
          id: "Apple",
          name: "Apple",
          price: "90k",
        },
        {
          id: "Nokia",
          name: "Nokia",
          price: "30k",
        },
      ],
    };
  },
  components: {
    AddNewDevice,
    DeviceDetail
  },
  methods: {
    AddDevice(ipname, ipprice) {
      if (!this.listvisible) {
        ipname = "";
        ipprice = "";
      }
      this.listvisible = !this.listvisible;
      if (ipname != "" && ipprice != "") {
        const newphone = {
          id: ipname,
          name: ipname,
          price: ipprice,
        };
        this.list.push(newphone);
      }
      ipname = "";
      ipprice = "";
    },
    deleteitem(idx) {
    this.list = this.list.filter((device) => device.id !== idx);
  },
  showdetail(idn) {
    this.showinfo = true;
    this.devid = idn;
    const device = this.list.find(item => item.id === idn);
    this.devname = device.name;
    this.devprice = device.price;
  },
  offlist() {
    this.showinfo = false;
  }
  },
  
};
</script>

<style>


template {
   box-sizing: border-box;
  font-family: "Jost", sans-serif;
  background-color: black;
  margin: 0;
}


section {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  margin: 0rem;
  border-radius: 10px;
  padding: 1rem;
  text-align: center;
  background-color: rgb(10, 9, 9);
}

h2 {
  font-size: 2rem;
  border-bottom: 4px solid #ccc;
  color: #93da63;
  margin: 0 0 1rem 0;
  text-align: center;
}

ul {
  list-style: none;
  margin: 1rem 0;
  padding: 0;
}

li {
  margin: 1rem 0;
  font-size: 1.25rem;
  font-weight: bold;
  background-color: #8d9bdb;
  padding: 0.5rem;
  color: #1f1f1f;
  border-radius: 20px;
  text-align: left;
}

input {
  font: inherit;
  border: 1px solid rgb(69, 68, 77);
  padding-right: 10px;
}

input:focus {
  outline: none;
  border-color: #14010c;
  background-color: #eeeeee;
}

button {
  font: inherit;
  cursor: pointer;
  border: 1px solid #010a14;
  background-color: #92939b;
  color: white;
  padding: 1.5rem 1rem;
  box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.26);
  border-radius: 20px;
  margin-left: 10px;
}
li button {
  font: inherit;
  cursor: pointer;
  border: 1px solid #010a14;
  background-color: #92939b;
  color: white;
  padding: 0.05rem 1rem;
  box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.26);
  float: right;
  margin-right: 20px;
}
</style>




