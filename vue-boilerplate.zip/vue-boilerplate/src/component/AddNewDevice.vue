<template>
    <div>
    <input type="text" v-if="listVisible" v-model="inputValue" placeholder="Device Name" />
    <input type="text" v-if="listVisible" v-model="inputPrice" placeholder="Device Price" />
    <button  @click="addDevice">Add New Device</button>
    
    </div>
</template>
<script>

export default {
  emit: ["add-newphone"],
  props: ['listVisible'],
  data() {
    return {
      inputValue: "",
      inputPrice: "",
    };
  },
  methods: {
    addDevice() {
      if(!this.listVisible)
      {
          this.inputValue = '';
          this.inputPrice = '';
      }
      this.$emit("add-newphone", this.inputValue, this.inputPrice);
      
    },
  },
};
</script>
<style>
div{
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
  margin: 0rem;
  border-radius: 10px;
  padding: 1rem;
  text-align: center;
  background-color: rgb(10, 9, 9);
}

input {
  font: inherit;
  border: 1px solid rgb(69, 68, 77);
  border-radius: 10px;
  padding: 10px;
  margin-right: 5px;
  margin-bottom: 5px;
  background-color: #e3eadf;
}

</style>
