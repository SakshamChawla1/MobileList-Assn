<template>
        <div>
        <h1><strong>Device Specifications</strong></h1>
        <h2>Device Id : {{id}}</h2>
        <h2>Device Name : {{devname}} </h2>
        <h2>Device Price : {{devprice}}</h2>
        <button @click="closelist">Okay</button>
        <router-view></router-view>
        </div>          
</template>
 <script>
 export default{
     props : ['id','devname','devprice','showinfo'],
     emits : ['close'],
     methods :{
         closelist(){
             this.$emit('close');
         }
     }
     

 };
 </script>
 
style <style scoped>
div {
    margin: 0;
    position: fixed;
    top : 20vh;
    left: 30%;
    width: 40%;
    height: 40%;
    background-color: white;
    box-shadow: 0 2px 8px black;
    padding : 1rem;
}
/* h1{
    font-family: sans-serif;
    font-size: 2.2rem;
    margin-top: 0;
} */
</style>